//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
str = "Swift is awesome!"

str = "Concatenate " + "two strings"

let anotherString = "This is another string"

anotherString = "changing fails"